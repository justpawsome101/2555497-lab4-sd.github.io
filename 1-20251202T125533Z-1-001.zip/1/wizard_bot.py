#!/usr/bin/env python3
import socket
import time
import json
import os
import random
from collections import defaultdict

# ================== CONFIG ==================
HOST = "10.80.156.74"
PORT = 2224
KNOWLEDGE_FILE = "wizard_knowledge.json"

# ================== GLOBAL STATE ==================
spell_classes = {}  # spell -> class_id
class_relations = {}  # class_id -> {"beats": class_id, "beaten_by": [class_ids]}
spell_outcomes = defaultdict(lambda: {"wins": set(), "loses": set(), "draws": set()})
all_spells_seen = set()

# ================== KNOWLEDGE MANAGEMENT ==================

def load_knowledge():
    """Load existing knowledge from file"""
    global spell_classes, class_relations, spell_outcomes, all_spells_seen
    
    if not os.path.exists(KNOWLEDGE_FILE):
        print("[*] No existing knowledge file found. Starting fresh.")
        return
    
    with open(KNOWLEDGE_FILE, "r") as f:
        data = json.load(f)
    
    spell_classes = data.get("spell_classes", {})
    class_relations = data.get("class_relations", {})
    
    # Reconstruct spell_outcomes
    raw_outcomes = data.get("spell_outcomes", {})
    for spell, info in raw_outcomes.items():
        spell_outcomes[spell] = {
            "wins": set(info.get("wins", [])),
            "loses": set(info.get("loses", [])),
            "draws": set(info.get("draws", []))
        }
    
    all_spells_seen = set(data.get("all_spells_seen", []))
    
    print(f"[+] Loaded knowledge: {len(all_spells_seen)} spells seen, {len(spell_classes)} classified")
    print(f"[+] Discovered {len(class_relations)} class relationships")


def save_knowledge():
    """Save current knowledge to file"""
    data = {
        "spell_classes": spell_classes,
        "class_relations": class_relations,
        "all_spells_seen": list(all_spells_seen),
        "spell_outcomes": {
            spell: {
                "wins": list(info["wins"]),
                "loses": list(info["loses"]),
                "draws": list(info["draws"])
            }
            for spell, info in spell_outcomes.items()
        }
    }
    
    with open(KNOWLEDGE_FILE, "w") as f:
        json.dump(data, f, indent=2)
    
    print(f"[+] Saved knowledge: {len(all_spells_seen)} spells")
    print(f"[+] Outcome data for {len(spell_outcomes)} spells")
    print(f"[+] Classes: {len(set(spell_classes.values()))} unique classes")


def categorize_spells():
    """
    Analyze spell_outcomes to group spells into classes.
    Spells that draw with each other are in the same class.
    """
    global spell_classes, class_relations
    
    print(f"[*] Analyzing spell outcomes for classification...")
    
    # First, make sure all spells are in spell_outcomes
    for spell in all_spells_seen:
        if spell not in spell_outcomes:
            spell_outcomes[spell] = {"wins": set(), "loses": set(), "draws": set()}
    
    # Reset classifications
    spell_classes = {}
    class_relations = {}
    
    # Group by draw relationships
    classes = []
    processed = set()
    
    for spell in all_spells_seen:
        if spell in processed:
            continue
        
        # Find all spells that draw with this one (including itself)
        draws_with_spell = spell_outcomes[spell]["draws"].copy()
        draws_with_spell.add(spell)  # Add self
        
        # Find transitive draws (if A draws with B, and B draws with C, then A,B,C are in same class)
        to_check = list(draws_with_spell)
        while to_check:
            current = to_check.pop()
            if current not in draws_with_spell:
                draws_with_spell.add(current)
                # Add all spells that draw with current
                for new_spell in spell_outcomes[current]["draws"]:
                    if new_spell not in draws_with_spell:
                        to_check.append(new_spell)
        
        classes.append(draws_with_spell)
        processed.update(draws_with_spell)
    
    # Assign class IDs
    for i, spell_set in enumerate(classes):
        class_id = str(i)
        for spell in spell_set:
            spell_classes[spell] = class_id
    
    print(f"[+] Found {len(classes)} unique spell classes")
    
    # Build class relations
    analyze_class_relations()


def analyze_class_relations():
    """
    Determine which classes beat which based on spell outcomes.
    """
    global class_relations
    
    class_to_spells = defaultdict(set)
    for spell, cls in spell_classes.items():
        class_to_spells[cls].add(spell)
    
    # Initialize class relations
    for cls in class_to_spells:
        class_relations[cls] = {"beats": set(), "beaten_by": set()}
    
    # Analyze wins between classes
    for spell, outcomes in spell_outcomes.items():
        if spell not in spell_classes:
            continue
        
        spell_class = spell_classes[spell]
        
        for beaten_spell in outcomes["wins"]:
            if beaten_spell in spell_classes:
                beaten_class = spell_classes[beaten_spell]
                if spell_class != beaten_class:
                    class_relations[spell_class]["beats"].add(beaten_class)
                    class_relations[beaten_class]["beaten_by"].add(spell_class)
    
    # Convert sets to lists for JSON serialization
    for cls in class_relations:
        class_relations[cls]["beats"] = list(class_relations[cls]["beats"])
        class_relations[cls]["beaten_by"] = list(class_relations[cls]["beaten_by"])
    
    print(f"[+] Built relationships between {len(class_relations)} classes")


# ================== NETWORKING ==================

def recv_exact(sock, n):
    data = b""
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise ConnectionError("Disconnected")
        data += chunk
    return data


def read_msg(sock):
    header = recv_exact(sock, 5)
    mtype = header[0]
    length = int.from_bytes(header[1:5], "little")
    payload = recv_exact(sock, length)
    return mtype, payload


def send_msg(sock, mtype, text):
    b = text.encode("utf-8")
    header = bytes([mtype]) + len(b).to_bytes(4, "little")
    sock.sendall(header + b)


def decode_text(b):
    return b.decode("utf-8", errors="replace").rstrip("\r\n")


# ================== SPELL HANDLING ==================

def record_outcome(our_spell, wizard_spell, outcome):
    """Record the outcome of a spell duel"""
    all_spells_seen.add(our_spell)
    all_spells_seen.add(wizard_spell)
    
    if outcome == "win":
        spell_outcomes[our_spell]["wins"].add(wizard_spell)
        spell_outcomes[wizard_spell]["loses"].add(our_spell)
    elif outcome == "lose":
        spell_outcomes[our_spell]["loses"].add(wizard_spell)
        spell_outcomes[wizard_spell]["wins"].add(our_spell)
    elif outcome == "draw":
        spell_outcomes[our_spell]["draws"].add(wizard_spell)
        spell_outcomes[wizard_spell]["draws"].add(our_spell)


def get_test_spell(wizard_spell, mode="level1"):
    """
    Get a spell to test against wizard_spell.
    
    mode can be:
      - "level1": systematic testing for learning relationships
      - "explore": random testing
      - "win": use best known counter
    """
    if mode == "level1":
        # In Level 1 mode, we want to systematically learn relationships
        
        # First, always record that a spell draws with itself
        if wizard_spell not in spell_outcomes or wizard_spell not in spell_outcomes[wizard_spell]["draws"]:
            return wizard_spell  # Return same spell to confirm draw
        
        # Check what we already know about this wizard spell
        if wizard_spell in spell_outcomes:
            known_outcomes = spell_outcomes[wizard_spell]
            
            # Find spells we haven't tested against this one
            tested_against = (known_outcomes["wins"] | 
                            known_outcomes["loses"] | 
                            known_outcomes["draws"])
            
            untested = [s for s in all_spells_seen if s not in tested_against and s != wizard_spell]
            
            if untested:
                # Test an untested spell
                return random.choice(untested[:10])  # Limit to first 10 for variety
        
        # If we've tested everything or have no data, test a random spell
        spells_list = list(all_spells_seen)
        if len(spells_list) > 1:
            return random.choice([s for s in spells_list if s != wizard_spell])
        return wizard_spell
    
    elif mode == "explore":
        # Random exploration
        spells_list = list(all_spells_seen)
        if len(spells_list) > 1:
            return random.choice([s for s in spells_list if s != wizard_spell])
        return wizard_spell
    
    else:  # "win" mode - use best known counter
        if wizard_spell in spell_outcomes:
            # Check if we know any spells that beat this one
            for spell, outcomes in spell_outcomes.items():
                if wizard_spell in outcomes["wins"]:
                    return spell
        
        # If no known counter, return a random spell
        spells_list = list(all_spells_seen)
        if spells_list:
            return random.choice(spells_list)
        return wizard_spell


def find_counter(wizard_spell):
    """Find the best counter for a wizard's spell using class knowledge"""
    if wizard_spell in spell_classes:
        wizard_class = spell_classes[wizard_spell]
        
        # Find a class that beats this one
        for cls, relations in class_relations.items():
            if wizard_class in relations["beats"]:
                # Pick any spell from this winning class
                for spell, spell_cls in spell_classes.items():
                    if spell_cls == cls:
                        return spell
    
    # Fallback: check direct outcomes
    for spell, outcomes in spell_outcomes.items():
        if wizard_spell in outcomes["wins"]:
            return spell
    
    # No counter known - try a random spell
    if all_spells_seen:
        return random.choice(list(all_spells_seen))
    return wizard_spell


# ================== BATTLE LOGIC ==================

def play_battle(mode="level1", stop_at_level2=True):
    """
    Play one complete battle.
    
    mode: "level1", "explore", or "win"
    stop_at_level2: if True, disconnect when level 2 starts (for farming level 1)
    """
    s = socket.create_connection((HOST, PORT), timeout=15)
    print(f"[+] Connected")
    
    level = 1
    last_our_spell = None
    last_wizard_spell = None
    
    try:
        while True:
            mtype, payload = read_msg(s)
            
            if mtype == 0x0:
                text = decode_text(payload)
                low = text.lower()
                
                # Show abbreviated server messages
                if len(text) > 100:
                    print(f"[S] {text[:100]}...")
                else:
                    print(f"[S] {text}")
                
                # Check for anti-bot
                if "not be a wuzhzard" in low or "wrists suddenly go limp" in low:
                    print("[!] Anti-bot detected, ending battle")
                    break
                
                # Level detection
                if "never heard before" in text:
                    print("\n[*] LEVEL 2 DETECTED")
                    level = 2
                    
                    # If we're farming level 1, disconnect now
                    if stop_at_level2:
                        print("[*] Stopping at Level 2 (farming Level 1 mode)")
                        break
                    
                elif "third duel" in low:
                    print("\n[*] LEVEL 3 DETECTED")
                    level = 3
                
                # Outcome detection and recording
                if last_our_spell and last_wizard_spell:
                    outcome_recorded = False
                    if "you beat the professor" in low or "you defeat the professor" in low:
                        print(f"[✓] WIN: {last_our_spell} > {last_wizard_spell}")
                        record_outcome(last_our_spell, last_wizard_spell, "win")
                        outcome_recorded = True
                    elif "professor beat you" in low:
                        print(f"[✗] LOSE: {last_our_spell} < {last_wizard_spell}")
                        record_outcome(last_our_spell, last_wizard_spell, "lose")
                        outcome_recorded = True
                    elif "draw" in low:
                        print(f"[=] DRAW: {last_our_spell} = {last_wizard_spell}")
                        record_outcome(last_our_spell, last_wizard_spell, "draw")
                        outcome_recorded = True
                    
                    if outcome_recorded:
                        # Show current knowledge stats
                        if last_wizard_spell in spell_outcomes:
                            outcomes = spell_outcomes[last_wizard_spell]
                            print(f"    {last_wizard_spell} stats: W{len(outcomes['wins'])}/L{len(outcomes['loses'])}/D{len(outcomes['draws'])}")
                    
                    last_our_spell = None
                    last_wizard_spell = None
                
                # Flag detection
                if "MWR{" in text:
                    print(f"\n{'='*60}")
                    print(f"[FLAG FOUND] {text}")
                    print(f"{'='*60}\n")
                
            elif mtype == 0x1:
                spell_chain = decode_text(payload)
                words = spell_chain.split('-')
                wizard_first = words[0]
                
                # Add all spells in chain to our seen list
                for word in words:
                    all_spells_seen.add(word)
                
                print(f"[W] {spell_chain[:80]}{'...' if len(spell_chain) > 80 else ''}")
                
                if level == 1:
                    # Level 1: We can experiment with different spells
                    if mode == "level1":
                        # Try to learn relationships
                        response_first = get_test_spell(wizard_first, mode)
                    else:
                        # In explore or win mode at level 1, just mirror
                        response_first = wizard_first
                    
                    # Build response - in Level 1 we can only change first word?
                    # Actually in Level 1, we might be able to change only the first word
                    # Let's try changing just the first word
                    if response_first != wizard_first:
                        words[0] = response_first
                        response = "-".join(words)
                    else:
                        response = spell_chain
                    
                    # Track for outcome recording
                    last_wizard_spell = wizard_first
                    last_our_spell = response_first
                    
                elif level == 2:
                    # Level 2: change only first word
                    response_first = get_test_spell(wizard_first, mode)
                    words[0] = response_first
                    response = "-".join(words)
                    
                    # Track for outcome recording
                    last_wizard_spell = wizard_first
                    last_our_spell = response_first
                    
                else:
                    # Level 3+: counter each word
                    countered_words = []
                    for w in words:
                        if mode == "win":
                            countered_words.append(find_counter(w))
                        else:
                            countered_words.append(get_test_spell(w, mode))
                    response = "-".join(countered_words)
                    response_first = countered_words[0]
                    
                    # Track for outcome recording
                    last_wizard_spell = wizard_first
                    last_our_spell = response_first
                
                time.sleep(random.uniform(0.3, 0.9))
                send_msg(s, 0x1, response)
                print(f"[Y] {response[:80]}{'...' if len(response) > 80 else ''}")
                
    except Exception as e:
        print(f"[!] Error: {e}")
    finally:
        s.close()
        save_knowledge()
        if mode == "level1":
            # Only categorize after level 1 battles when we have outcome data
            categorize_spells()


# ================== ANALYSIS FUNCTIONS ==================

def analyze_knowledge():
    """Analyze and display current knowledge"""
    print(f"\n{'='*60}")
    print("KNOWLEDGE ANALYSIS")
    print(f"{'='*60}")
    
    print(f"Total spells seen: {len(all_spells_seen)}")
    print(f"Spells with outcome data: {len(spell_outcomes)}")
    
    # Show spells with most known outcomes
    print("\nMost tested spells:")
    sorted_spells = sorted(spell_outcomes.items(), 
                          key=lambda x: len(x[1]['wins']) + len(x[1]['loses']) + len(x[1]['draws']), 
                          reverse=True)[:10]
    
    for spell, outcomes in sorted_spells:
        total = len(outcomes['wins']) + len(outcomes['loses']) + len(outcomes['draws'])
        print(f"  {spell[:20]:20} W:{len(outcomes['wins']):3} L:{len(outcomes['loses']):3} D:{len(outcomes['draws']):3} Total:{total:3}")
    
    # Show class information
    if spell_classes:
        print(f"\nClass information:")
        print(f"  Unique classes: {len(set(spell_classes.values()))}")
        
        class_counts = defaultdict(int)
        for spell, cls in spell_classes.items():
            class_counts[cls] += 1
        
        print(f"\n  Class sizes:")
        for cls, count in sorted(class_counts.items(), key=lambda x: x[1], reverse=True)[:10]:
            # Get example spells from this class
            examples = [s for s, c in spell_classes.items() if c == cls][:3]
            print(f"    Class {cls}: {count:3} spells (e.g., {', '.join(examples)})")
        
        # Show class relationships
        if class_relations:
            print(f"\n  Class relationships:")
            for cls, relations in class_relations.items():
                if relations["beats"]:
                    print(f"    Class {cls} beats: {', '.join(relations['beats'])}")
    
    print(f"{'='*60}")


# ================== MAIN ==================

def main():
    print("=" * 70)
    print("SPACE WIZARD CTF SOLVER - ENHANCED")
    print("=" * 70)
    
    load_knowledge()
    
    while True:
        print(f"\nCurrent stats: {len(all_spells_seen)} spells seen")
        
        print("\n[?] Select mode:")
        print("    1. Farm Level 1 (discover spells AND learn relationships)")
        print("    2. Explore Level 2 (continue learning)")
        print("    3. Win Mode (use knowledge to beat the wizard)")
        print("    4. Analyze current knowledge")
        print("    5. Clear knowledge and start fresh")
        print("    6. Exit")
        
        choice = input("\nChoice [1-6]: ").strip()
        
        if choice == "1":
            print("\n[*] FARM LEVEL 1 MODE")
            print("[*] Will learn spell relationships in Level 1")
            print("[*] Will disconnect when Level 2 starts")
            
            num_battles = int(input("How many battles to farm? [10]: ") or "10")
            
            for i in range(num_battles):
                print(f"\n{'='*60}")
                print(f"BATTLE #{i+1}/{num_battles} - Spells: {len(all_spells_seen)}")
                if spell_outcomes:
                    total_tests = sum(len(o['wins']) + len(o['loses']) + len(o['draws']) 
                                    for o in spell_outcomes.values())
                    print(f"           - Known outcomes: {total_tests}")
                print(f"{'='*60}")
                
                play_battle(mode="level1", stop_at_level2=True)
                
                if i < num_battles - 1:
                    wait = random.uniform(1.5, 3.5)
                    print(f"[*] Waiting {wait:.1f}s before next battle...")
                    time.sleep(wait)
        
        elif choice == "2":
            print("\n[*] EXPLORE LEVEL 2 MODE")
            print("[*] Will play through Level 2, continuing to learn\n")
            
            num_battles = int(input("How many battles to explore? [5]: ") or "5")
            
            for i in range(num_battles):
                print(f"\n{'='*60}")
                print(f"BATTLE #{i+1}/{num_battles}")
                print(f"{'='*60}")
                
                play_battle(mode="explore", stop_at_level2=False)
                
                if i < num_battles - 1:
                    wait = random.uniform(2, 4)
                    print(f"[*] Waiting {wait:.1f}s before next battle...")
                    time.sleep(wait)
        
        elif choice == "3":
            print("\n[*] WIN MODE")
            print("[*] Using knowledge to beat the wizard\n")
            
            if not class_relations:
                print("[!] Warning: No class relationships known yet!")
                print("[!] You should farm Level 1 first to learn relationships")
                continue
            
            num_battles = int(input("How many attempts? [3]: ") or "3")
            
            for i in range(num_battles):
                print(f"\n{'='*60}")
                print(f"ATTEMPT #{i+1}/{num_battles}")
                print(f"{'='*60}")
                
                play_battle(mode="win", stop_at_level2=False)
                
                if i < num_battles - 1:
                    wait = random.uniform(2, 5)
                    print(f"[*] Waiting {wait:.1f}s before next attempt...")
                    time.sleep(wait)
        
        elif choice == "4":
            analyze_knowledge()
        
        elif choice == "5":
            confirm = input("Are you sure you want to clear all knowledge? (y/n): ").strip().lower()
            if confirm == 'y':
                if os.path.exists(KNOWLEDGE_FILE):
                    os.remove(KNOWLEDGE_FILE)
                spell_classes.clear()
                class_relations.clear()
                spell_outcomes.clear()
                all_spells_seen.clear()
                print("[+] Knowledge cleared!")
        
        elif choice == "6":
            print("\n[+] Exiting. Goodbye!")
            break
        
        else:
            print("[!] Invalid choice")


if __name__ == "__main__":
    main()
